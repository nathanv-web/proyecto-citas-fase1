import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-diagnosis',
  styleUrl: './diagnosis.css',
  templateUrl: './diagnosis.html',
})
export class Diagnosis {
}
